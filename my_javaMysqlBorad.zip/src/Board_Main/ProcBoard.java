package Board_Main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class ProcBoard {
	Connection con = null;
	Statement st = null;
	ResultSet result = null;
	
	Scanner sc = new Scanner(System.in);
	
	 void run() {
		dbInit();
//		dbExecuteQuery("select * from tottenham_squad where p_number=7");
		loop:
			while(true) {
				Disp.showTitle();
				Disp.showMainMenu();
				String cmd = sc.next();
				switch(cmd) {
				case "1":
					System.out.println("리스트 기능을 실행합니다");
					System.out.println("=====================================");
					System.out.println("==============글 리스트=================");
					System.out.println("=====================================");
					System.out.println("글 번호, 글 제목, 작성자id, 작성시간");
					try {
						result = st.executeQuery("select * from sec_board");
						while(result.next()){
						String no = result.getString("b_no");
						String title = result.getString("b_title");
						String id = result.getString("b_id");
						String datetime = result.getString("b_datetime");
						System.out.println(no + " " + title + " " +id + " " + datetime);
						}
						
					} catch (SQLException e) {
						e.printStackTrace();
					}
					break;
					
				case "2":
					System.out.println("읽기 기능을 실행합니다");
					String ReadNo = sc.next();
					try {
						result = st.executeQuery("select * from sec_board where b_no ="+ReadNo);
						result.next();
						String title = result.getString("b_title");
						String content = result.getString("b_text");
						System.out.println("글 제목 :" + title);
						System.out.println("글 내용 :" + content);
					} catch (SQLException e) {
						e.printStackTrace();
					}
					
				case "3":
					System.out.println("글쓰기 기능을 실행합니다");
					System.out.println("");
					System.out.println("id를 입력해주세요");
					String id;
					while(true){
						id = sc.next();
						if(id.length()>3) {
							System.out.println("");
							break;
						} else {
							System.out.println("다시 입력해주세요");
						}
					}
					
					sc.nextLine(); // sc.next()를 썻으니 공백까지 인식하는 이 함수로 다시 바꿔야한다
					String title;
					System.out.println("");
					System.out.println("제목을 입력해주세요");
					while(true) {
						title = sc.nextLine();
						if (title.length()>0) {
							System.out.println("");
							break;
						}else {
							System.out.println("글자수가 부족합니다");
						}
					}
					
					
					
					
					String content;
					System.out.println("");
					System.out.println("내용을 입력해주세요");
					while(true) {
						content = sc.nextLine();
						if(content.length()>3) {
							System.out.println("");
							break;
						}else {
							System.out.println("글자수가 부족합니다");
						}
					}
					
					String sql;
					sql = String.format("insert into sec_board (b_title, b_id, b_datetime, b_text, b_hit)"
					+"values ('%s', '%s', now(), '%s', 0)",title, id, content);
					System.out.println(sql);
					try {
						st.executeUpdate(sql);
						System.out.println("글 등록 완료");
					}catch (SQLException e) {
						e.printStackTrace();
					}
				
					//dbExcuteUpdate("insert into sec_board (b_title, b_id, b_datetime, b_text, b_hit) 
//					values('"+title+"', '"+ id +"', now(), '"+content+"', 0);");
					break;
					
				case "4":
					System.out.println("삭제 기능을 실행합니다");
					System.out.println("");
					System.out.println("삭제할 번호를 입력해주세요");
					String DelNo = sc.next();
					if(DelNo.equals("x")) {
						System.out.println("이전 메뉴로 돌아갑니다");
						break;
					}
					String sql_1 = "delete from sec_board where b_no =" + DelNo;
					System.out.println(sql_1);
					dbExecuteUpdate(sql_1);
					break;
					
				case "5":
					System.out.println("글 수정 기능을 실행합니다");
					System.out.println("");
					System.out.println("글을 수정할 번호를 입력해주세요");
					String editNo = sc.next();
					if(editNo.equals("x")) {
						System.out.println("이전 메뉴로 돌아갑니다");
						break;
					}
					
					
					sc.nextLine();
					System.out.println("수정할 글 제목을 입력해주세요");
					String ed_title = sc.nextLine();
					
					System.out.println("수정할 id를 입력해주세요");
					String ed_id = sc.next();
					
					sc.nextLine();
					System.out.println("수정할 내용을 입력해주세요");
					String ed_cont = sc.nextLine();
					
					dbExecuteUpdate("update sec_board set b_title ='" + ed_title + "', b_id ='" +ed_id+ "', b_datetime = now(), b_text ='"+ed_cont+"' where b_no =" +editNo );
					break;
					
					
				case "0":
					System.out.println("임시 관리자 기능 실행");
					break loop;
				}
				
				
			}
		
		
		
		
	}
	private void dbInit() {
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			st = con.createStatement();
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	
	private void dbExecuteQuery(String query) {
		try {
			result = st.executeQuery(query);
			while(result.next()){
				String name = result.getString("p_name");
				System.out.println(name);
			}
			}catch(SQLException e) {
				System.out.println("SQLException: " + e.getMessage());
				System.out.println("SQLState: " + e.getSQLState());
			}
		
	}
	
	private void dbExecuteUpdate(String query) {
		try {
			int resultCount = st.executeUpdate(query);
			System.out.println("처리된 행 수:"+resultCount);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
}
