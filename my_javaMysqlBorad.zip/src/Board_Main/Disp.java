package Board_Main;

public class Disp {

	static private String TITLE_BAR = "🦉🦉🦉🦉🦉🦉🦉🦉🦉🦉🦉🦉🦉🦉🦉🦉🦉🦉🦉🦉🦉🦉🦉🦉🦉";
	static private String TITLE     = "🦉🦉🦉🦉🦉🦉🦉🦉🦉🦉   게시판   🦉🦉🦉🦉🦉🦉🦉🦉🦉🦉";
			
	static private String MAIN_MENU_BAR = "=======================================================";
	static private String MAIN_MENU = "[1]글 리스트 [2]글 읽기 [3]글 작성 [4]글 삭제 [5]글 수정 [0]파일 관리자";
	
	
	
	static public void showTitle() {
		System.out.println(TITLE_BAR);
		System.out.println(TITLE);
		System.out.println(TITLE_BAR);
	}
			
			static public void showMainMenu() {
				System.out.println(MAIN_MENU_BAR);
				System.out.println(MAIN_MENU);
				System.out.println(MAIN_MENU_BAR);
			}
			
			
			
			
			
			
}
